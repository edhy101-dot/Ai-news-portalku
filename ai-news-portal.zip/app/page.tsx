import { fetchAllFeeds } from "@/lib/fetchFeeds";
import ArticleCard from "@/components/ArticleCard";

export const revalidate = 600; // ISR 10 menit

export default async function HomePage() {
  const items = await fetchAllFeeds();
  return (
    <div className="space-y-8">
      <section className="container-hero">
        <h1 className="text-2xl md:text-3xl font-bold">Berita & Artikel Terbaru</h1>
        <p className="text-muted mt-1">Teknologi • Perkembangan AI • Olahraga • Lifestyle • Selebritis</p>
      </section>

      <section className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {items.slice(0, 30).map(item => (
          <ArticleCard key={item.id} item={item} />
        ))}
      </section>
    </div>
  );
}
