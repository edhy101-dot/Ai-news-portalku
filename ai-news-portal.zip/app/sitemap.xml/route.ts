import { fetchAllFeeds } from "@/lib/fetchFeeds";

export const revalidate = 600;

export async function GET() {
  const items = await fetchAllFeeds();
  const urls = items.slice(0,200).map(i=>`
    <url>
      <loc>https://example.com/artikel/${i.slug}</loc>
      <lastmod>${new Date(i.isoDate || i.pubDate || Date.now()).toISOString()}</lastmod>
    </url>
  `).join("\n");

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
  <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <url><loc>https://example.com/</loc></url>
    ${urls}
  </urlset>`;

  return new Response(xml, { status: 200, headers: { "Content-Type": "application/xml" } });
}
