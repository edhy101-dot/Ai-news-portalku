import { fetchAllFeeds } from "@/lib/fetchFeeds";
import { CATEGORIES } from "@/lib/sources";
import ArticleCard from "@/components/ArticleCard";
import { notFound } from "next/navigation";

export const revalidate = 600;

export default async function CategoryPage({ params }: { params: { slug: string }}) {
  const catKey = params.slug as keyof typeof CATEGORIES;
  if (!CATEGORIES[catKey]) return notFound();

  const items = await fetchAllFeeds(catKey);
  const catName = CATEGORIES[catKey].name;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl md:text-3xl font-bold">{catName}</h1>
      <section className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {items.map(item => (
          <ArticleCard key={item.id} item={item} />
        ))}
      </section>
    </div>
  );
}
