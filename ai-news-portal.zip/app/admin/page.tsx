'use client';

import { useEffect, useMemo, useState } from "react";
import { slugify } from "@/lib/slugify";

type ManualPost = {
  id: string;
  title: string;
  image?: string;
  content: string;
  category: string;
  createdAt: number;
  slug: string;
};

const LS_KEY = "ai-news-portal:manual-posts";
const PASS = process.env.NEXT_PUBLIC_ADMIN_PASS || "";

export default function AdminPage() {
  const [authed, setAuthed] = useState(false);
  const [pass, setPass] = useState("");
  const [posts, setPosts] = useState<ManualPost[]>([]);
  const [form, setForm] = useState<Partial<ManualPost>>({ category: "Teknologi" });

  useEffect(() => {
    const saved = localStorage.getItem(LS_KEY);
    setPosts(saved ? JSON.parse(saved) : []);
  }, []);

  function savePosts(next: ManualPost[]) {
    setPosts(next);
    localStorage.setItem(LS_KEY, JSON.stringify(next));
  }

  function onSubmit() {
    const title = (form.title || "").trim();
    if (!title) return alert("Judul wajib diisi");
    const now = Date.now();
    const newPost: ManualPost = {
      id: `${now}`,
      title,
      image: form.image || "",
      content: form.content || "",
      category: form.category || "Teknologi",
      createdAt: now,
      slug: `${slugify(title)}-${String(now).slice(-6)}`
    };
    const next = [newPost, ...posts];
    savePosts(next);
    setForm({ category: "Teknologi" });
  }

  function remove(id: string) {
    if (!confirm("Hapus artikel ini?")) return;
    savePosts(posts.filter(p => p.id !== id));
  }

  function exportJson() {
    const blob = new Blob([JSON.stringify(posts, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "manual-posts.json";
    a.click();
    URL.revokeObjectURL(url);
  }

  function importJson(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(String(reader.result||"[]"));
        if (Array.isArray(data)) savePosts(data);
      } catch {
        alert("File tidak valid");
      }
    };
    reader.readAsText(file);
  }

  if (!authed) {
    return (
      <div className="max-w-md mx-auto card">
        <h1 className="text-xl font-semibold">Login Admin</h1>
        <p className="text-muted mt-1">Masukkan password admin.</p>
        <input className="input mt-3" type="password" value={pass} onChange={e=>setPass(e.target.value)} placeholder="Password" />
        <button className="btn btn-primary mt-3 w-full" onClick={()=>{
          if (PASS && pass !== PASS) return alert("Password salah");
          setAuthed(true);
        }}>Masuk</button>
        <p className="text-xs text-gray-400 mt-2">Set env <code>NEXT_PUBLIC_ADMIN_PASS</code> untuk mengaktifkan password.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="card">
        <h2 className="text-lg font-semibold">Tambah Artikel Manual</h2>
        <div className="grid md:grid-cols-2 gap-3 mt-3">
          <input className="input" placeholder="Judul" value={form.title||""} onChange={e=>setForm(f=>({...f, title:e.target.value}))} />
          <input className="input" placeholder="URL Gambar (opsional)" value={form.image||""} onChange={e=>setForm(f=>({...f, image:e.target.value}))} />
          <select className="input" value={form.category||"Teknologi"} onChange={e=>setForm(f=>({...f, category:e.target.value}))}>
            {["Teknologi","Perkembangan AI","Olahraga","Lifestyle","Selebritis"].map(c=>(
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
          <textarea className="input min-h-[120px]" placeholder="Konten ringkas" value={form.content||""} onChange={e=>setForm(f=>({...f, content:e.target.value}))} />
        </div>
        <button className="btn btn-primary mt-3" onClick={onSubmit}>Publikasikan</button>
      </div>

      <div className="card">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">Artikel Manual ({posts.length})</h2>
          <div className="flex gap-2">
            <button className="btn" onClick={exportJson}>Export JSON</button>
            <label className="btn cursor-pointer">
              Import JSON
              <input type="file" accept="application/json" onChange={importJson} className="hidden" />
            </label>
          </div>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
          {posts.map(p => (
            <div key={p.id} className="border rounded-2xl p-3">
              <div className="badge">{p.category}</div>
              <h3 className="font-semibold mt-1">{p.title}</h3>
              <p className="text-sm text-muted mt-1 line-clamp-3">{p.content}</p>
              <div className="flex gap-2 mt-3">
                <a className="btn" href={`/artikel/${p.slug}`} target="_blank">Lihat</a>
                <button className="btn" onClick={()=>remove(p.id)}>Hapus</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
