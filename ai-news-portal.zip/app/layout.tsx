import type { Metadata } from "next";
import "./globals.css";
import NavBar from "@/components/NavBar";

export const metadata: Metadata = {
  title: "AI News Portal — Teknologi, AI, Olahraga, Lifestyle, Selebritis",
  description: "Portal berita dan artikel terkini: Teknologi, Perkembangan AI, Olahraga, Lifestyle, dan Selebritis. Auto-update dari sumber populer, SEO-ready.",
  metadataBase: new URL("https://example.com"),
  openGraph: {
    title: "AI News Portal",
    description: "Berita dan artikel terkini dari berbagai kategori",
    type: "website"
  },
  alternates: {
    canonical: "/"
  }
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="id">
      <body className="min-h-screen">
        <NavBar />
        <main className="container py-6">{children}</main>
        <footer className="border-t border-gray-100 py-8 mt-10 text-center text-sm text-muted">
          © {new Date().getFullYear()} AI News Portal — Dibuat dengan Next.js + Tailwind.
        </footer>
      </body>
    </html>
  );
}
